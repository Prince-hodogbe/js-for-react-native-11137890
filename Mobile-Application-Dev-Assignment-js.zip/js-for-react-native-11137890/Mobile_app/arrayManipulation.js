// Create a JavaScript file named arrayManipulation.js
// Write a function processArray that manipulates numbers in an array
function processArray(numbers) {
    return numbers.map(num => num % 2 === 0 ? num ** 2 : num * 3);
}


// Task 2
function formatArrayStrings(strArr, numArr) {
  return strArr.map((str, i) => {
    if (numArr[i] % 2 === 0) {
      return str.toUpperCase();
    } else {
      return str.toLowerCase();
    }
  });
}

// Export the functions for use in other files
module.exports = { processArray, formatArrayStrings };


