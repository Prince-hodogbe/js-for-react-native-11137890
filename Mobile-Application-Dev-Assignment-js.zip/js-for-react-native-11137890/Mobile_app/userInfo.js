// Task 3
function createUserProfiles(names, modifiedNames) {
  const profiles = [];
  let id = 1;
  names.forEach((name, i) => {
    profiles.push({
      originalName: name,
      modifiedName: modifiedNames[i],
      id
    });
    id++;
  });
  return profiles;
}

// Export the function for use in other files
module.exports = { createUserProfiles };

